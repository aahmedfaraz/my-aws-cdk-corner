import avro


def handler(event):
    print("Ahmed Faraz")
    print("Event : ", event)
